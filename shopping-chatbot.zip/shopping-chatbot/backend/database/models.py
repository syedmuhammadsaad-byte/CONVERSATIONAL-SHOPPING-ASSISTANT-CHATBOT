from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, JSON
from sqlalchemy.orm import relationship
from datetime import datetime, timezone

def _utcnow():
    return datetime.now(timezone.utc)
from .db import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, unique=True, index=True, nullable=False)
    created_at = Column(DateTime, default=_utcnow)

    # Relationships
    conversations = relationship("Conversation", back_populates="user", cascade="all, delete-orphan")
    cart_items = relationship("CartItem", back_populates="user", cascade="all, delete-orphan")
    rl_states = relationship("RLState", back_populates="user", cascade="all, delete-orphan")


class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    role = Column(String, nullable=False)       # "user" or "assistant"
    message = Column(String, nullable=False)
    timestamp = Column(DateTime, default=_utcnow)

    user = relationship("User", back_populates="conversations")


class CartItem(Base):
    __tablename__ = "cart_items"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    product_id = Column(Integer, nullable=False)
    quantity = Column(Integer, default=1)
    added_at = Column(DateTime, default=_utcnow)

    user = relationship("User", back_populates="cart_items")


class RLState(Base):
    __tablename__ = "rl_states"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    session_id = Column(String, index=True, nullable=False)   # denormalised for fast lookup
    state_vector = Column(JSON, nullable=False)               # 389-dim list stored as JSON
    action_taken = Column(String, nullable=False)             # one of ACTIONS
    reward = Column(Float, nullable=False)
    timestamp = Column(DateTime, default=_utcnow)

    user = relationship("User", back_populates="rl_states")