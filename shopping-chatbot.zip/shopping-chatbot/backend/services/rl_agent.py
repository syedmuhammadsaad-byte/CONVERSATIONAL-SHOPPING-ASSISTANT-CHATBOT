"""
RL Contextual Bandit Agent — Phase 3 (fixed)
=============================================
Epsilon-greedy linear contextual bandit.

Key fixes applied:
  1. Intent-aware action selection — greeting/goodbye handled before RL
  2. Cold-start uses intent to decide whether to ask questions or greet
  3. Repeated-question guard blocks any ask_* used anywhere in session
  4. Auto-reward wired in chat router applies +1 when user gives useful info
"""

from __future__ import annotations

import json
import logging
import os
import random
from typing import Dict, List, Optional

import numpy as np

from services.nlu import UserIntent

logger = logging.getLogger(__name__)

# ── Hyperparameters ────────────────────────────────────────────────────────
EPSILON       = 0.15
LEARNING_RATE = 0.01
STATE_DIM     = 389
MAX_TURNS     = 20
MAX_CART      = 10

_HERE        = os.path.dirname(__file__)
WEIGHTS_PATH = os.path.join(_HERE, "..", "data", "rl_weights.json")


# ── Reward constants ───────────────────────────────────────────────────────
class Reward:
    PURCHASE_COMPLETED = +20.0
    ADD_TO_CART        = +5.0
    INFORMATIVE_ANSWER = +1.0
    USER_ABANDONS      = -10.0
    REPEATED_QUESTION  = -3.0


# ── Action space ──────────────────────────────────────────────────────────
ACTIONS: List[str] = [
    "ask_budget",
    "ask_style",
    "ask_urgency",
    "ask_category",
    "ask_brand",
    "recommend_products",
    "add_to_cart",
    "transfer_to_human",
    "end_conversation",
]

ACTION_QUESTIONS: Dict[str, str] = {
    "ask_budget":          "What's your budget range?",
    "ask_style":           "What style are you looking for?",
    "ask_urgency":         "When do you need this by?",
    "ask_category":        "What category are you shopping in?",
    "ask_brand":           "Do you have a preferred brand?",
    "recommend_products":  "",
    "add_to_cart":         "",
    "transfer_to_human":   "Let me connect you with a human agent who can help further.",
    "end_conversation":    "Thanks for shopping with us! Have a great day.",
}

N_ACTIONS    = len(ACTIONS)
ACTION_INDEX = {a: i for i, a in enumerate(ACTIONS)}

# ── Cold-start sequence (used only for search/filter intents) ─────────────
# Ordered by how much information each question typically yields
COLD_START_SEQUENCE = [
    "ask_budget",
    "ask_category",
    "ask_style",
    "recommend_products",
    "ask_urgency",
    "ask_brand",
]

# ── Intents that should skip clarifying questions and go straight to action ─
TERMINAL_INTENTS = {
    "greeting":    "greet",           # handled before RL
    "goodbye":     "end_conversation",
    "add_to_cart": "add_to_cart",
    "checkout":    "end_conversation",
}

# ── Intents that should go straight to recommend after NLU extracts enough ─
DIRECT_RECOMMEND_INTENTS = {"search", "filter"}


# ═══════════════════════════════════════════════════════════════════════════
# Weight persistence
# ═══════════════════════════════════════════════════════════════════════════

def _load_weights() -> np.ndarray:
    if os.path.exists(WEIGHTS_PATH):
        try:
            with open(WEIGHTS_PATH, "r") as f:
                data = json.load(f)
            W = np.array(data["weights"], dtype=np.float64)
            if W.shape == (N_ACTIONS, STATE_DIM):
                logger.info("RL weights loaded from %s", WEIGHTS_PATH)
                return W
        except Exception as exc:
            logger.warning("Could not load weights (%s) — reinitialising.", exc)
    logger.info("Initialising RL weights to zero  shape=(%d, %d)", N_ACTIONS, STATE_DIM)
    return np.zeros((N_ACTIONS, STATE_DIM), dtype=np.float64)


def _save_weights(W: np.ndarray) -> None:
    os.makedirs(os.path.dirname(WEIGHTS_PATH), exist_ok=True)
    with open(WEIGHTS_PATH, "w") as f:
        json.dump({"weights": W.tolist(), "actions": ACTIONS}, f)


# ═══════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _already_asked(action: str, history: List[dict]) -> bool:
    """True if this ask_* action was used ANY time in this session."""
    if not action.startswith("ask_"):
        return False
    all_asked = {
        h["action"] for h in history
        if h.get("role") == "assistant" and "action" in h
    }
    return action in all_asked


def _missing_info(intent: UserIntent, history: List[dict]) -> List[str]:
    """
    Return list of ask_* actions that would gather still-unknown info.
    Used by cold-start and exploit fallback to pick the most useful question.
    """
    asked = {
        h["action"] for h in history
        if h.get("role") == "assistant" and "action" in h
    }
    missing = []
    if intent.budget is None          and "ask_budget"   not in asked: missing.append("ask_budget")
    if intent.style_preference is None and "ask_style"    not in asked: missing.append("ask_style")
    if intent.urgency is None          and "ask_urgency"  not in asked: missing.append("ask_urgency")
    # category and brand: ask if keywords are sparse
    if len(intent.keywords) < 2:
        if "ask_category" not in asked: missing.append("ask_category")
        if "ask_brand"    not in asked: missing.append("ask_brand")
    return missing


def _enough_info(intent: UserIntent) -> bool:
    """
    True if we have enough context to make a good recommendation.
    Require at least 2 of: budget, style_preference, 2+ keywords.
    This ensures the agent asks at least one clarifying question before recommending.
    """
    signals = 0
    if intent.budget          is not None: signals += 1
    if intent.style_preference is not None: signals += 1
    if len(intent.keywords)   >= 2:        signals += 1
    return signals >= 2


# ═══════════════════════════════════════════════════════════════════════════
# Agent
# ═══════════════════════════════════════════════════════════════════════════

class RLAgent:
    _instance: Optional["RLAgent"] = None

    def __init__(self):
        self.W               = _load_weights()
        self.epsilon         = EPSILON
        self.lr              = LEARNING_RATE
        self._update_count   = 0

    @classmethod
    def get(cls) -> "RLAgent":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # ── State construction ─────────────────────────────────────────────────

    def build_state_vector(
        self,
        nlu_intent: UserIntent,
        turn_number: int = 0,
        cart_size: int = 0,
    ) -> np.ndarray:
        embedding = np.array(nlu_intent.embedding, dtype=np.float64)
        if len(embedding) != 384:
            tmp = np.zeros(384, dtype=np.float64)
            tmp[:min(len(embedding), 384)] = embedding[:384]
            embedding = tmp

        context = np.array([
            1.0 if nlu_intent.budget          is not None else 0.0,
            1.0 if nlu_intent.style_preference is not None else 0.0,
            1.0 if nlu_intent.urgency          is not None else 0.0,
            min(turn_number, MAX_TURNS) / MAX_TURNS,
            min(cart_size,   MAX_CART)  / MAX_CART,
        ], dtype=np.float64)

        state = np.concatenate([embedding, context])
        assert state.shape == (STATE_DIM,)
        return state

    # ── Action selection ───────────────────────────────────────────────────

    def select_action(
        self,
        state_vector: np.ndarray,
        conversation_history: Optional[List[dict]] = None,
        intent: Optional[UserIntent] = None,
    ) -> str:
        """
        Choose an action using intent-aware epsilon-greedy policy.

        Priority order:
          1. Terminal intents (greeting, goodbye, checkout) → fixed response
          2. Enough info already → recommend_products
          3. Weights non-zero → epsilon-greedy exploitation/exploration
          4. Cold-start (zero weights) → ask for missing info in logical order
        """
        history = conversation_history or []

        # ── 1. Handle terminal intents immediately ─────────────────────────
        if intent is not None:
            if intent.intent == "greeting":
                return "greet"
            if intent.intent in ("goodbye", "checkout", "add_to_cart"):
                return TERMINAL_INTENTS.get(intent.intent, "end_conversation")

        # ── 2. Check if last action was recommend and user seems unsatisfied ──
        last_bot_action = next(
            (h.get("action") for h in reversed(history) if h.get("role") == "assistant"),
            None
        )
        last_was_recommend = last_bot_action == "recommend_products"

        # Negative signals after a recommendation → ask a clarifying question
        # Check raw keywords AND the original message text (passed via intent.keywords
        # before stopword filtering) by looking at the full keyword list
        negative_signals = {
            "not", "wrong", "no", "these", "dont", "bad",
            "wait", "different", "other", "else", "wrong",
            "incorrect", "nope", "nah", "unrelated", "irrelevant"
        }
        # Also check if the message contains negation patterns via intent
        # intent.keywords has stopwords removed, so check if remaining words
        # suggest rejection (e.g. "shoes" after seeing non-shoe products)
        all_kw = set(intent.keywords if intent else [])
        user_negative = (
            intent is not None
            and last_was_recommend
            and (
                # Direct negative keywords survived stopword filter
                any(kw in all_kw for kw in negative_signals)
                # OR: intent is unknown/question after a recommendation (confusion)
                or (intent.intent in ("unknown", "question") and not all_kw - {"wait","what","why","huh"})
                # OR: user is re-stating same product type (they want something different)
                or intent.intent == "search"
            )
        )

        if user_negative:
            # User rejected recommendations — ask a different clarifying question
            missing = _missing_info(intent, history)
            if missing:
                return missing[0]
            # All questions asked already — try recommend with updated context
            return "recommend_products"

        # ── 3. If we already have enough info → recommend ─────────────────
        if intent is not None and _enough_info(intent):
            user_turns = sum(1 for h in history if h.get("role") == "user")
            if user_turns >= 1 or intent.budget is not None:
                return "recommend_products"

        # ── 3b. Short/unclear reply → ask next missing question ───────────
        if intent is not None and intent.intent == "unknown" and not intent.keywords:
            missing = _missing_info(intent, history)
            if missing:
                return missing[0]
            return "recommend_products"

        # ── 3. Weights non-zero → epsilon-greedy ─────────────────────────
        if np.any(self.W):
            if random.random() < self.epsilon:
                # Explore: pick from actions not yet asked
                candidates = [a for a in ACTIONS if not _already_asked(a, history)]
                chosen = random.choice(candidates if candidates else ACTIONS)
                logger.debug("ε-explore → %s", chosen)
                return chosen

            # Exploit: pick highest-scoring non-repeated action
            scores = self.W @ state_vector
            ranked = sorted(range(N_ACTIONS), key=lambda i: scores[i], reverse=True)
            for idx in ranked:
                action = ACTIONS[idx]
                if not _already_asked(action, history):
                    logger.debug("ε-exploit → %s  score=%.4f", action, scores[idx])
                    return action

        # ── 4. Cold-start: ask for missing info in logical order ──────────
        if intent is not None:
            missing = _missing_info(intent, history)
            if missing:
                return missing[0]   # ask the most valuable unknown question

        # Fallback: if all questions asked or no intent, recommend
        return "recommend_products"

    # ── Weight update ──────────────────────────────────────────────────────

    def update(self, state_vector: np.ndarray, action: str, reward: float) -> None:
        if action not in ACTION_INDEX:
            raise ValueError(f"Unknown action '{action}'. Valid: {ACTIONS}")
        idx = ACTION_INDEX[action]
        self.W[idx] += self.lr * reward * state_vector
        self._update_count += 1
        logger.debug("update #%d  action=%s  reward=%.1f", self._update_count, action, reward)
        _save_weights(self.W)

    # ── Utilities ──────────────────────────────────────────────────────────

    def get_action_question(self, action_name: str) -> str:
        return ACTION_QUESTIONS.get(action_name, "")

    def action_scores(self, state_vector: np.ndarray) -> Dict[str, float]:
        scores = self.W @ state_vector
        return {action: float(scores[i]) for i, action in enumerate(ACTIONS)}

    def reset_weights(self) -> None:
        self.W = np.zeros((N_ACTIONS, STATE_DIM), dtype=np.float64)
        _save_weights(self.W)
        logger.info("RL weights reset to zero.")

    @property
    def update_count(self) -> int:
        return self._update_count