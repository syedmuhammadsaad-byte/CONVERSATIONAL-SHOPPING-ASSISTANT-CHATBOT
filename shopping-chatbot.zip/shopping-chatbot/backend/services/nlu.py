"""
NLU Service — Phase 2
=====================
Extracts structured intent + entities from raw user messages.

Embedding backend
-----------------
In this sandbox HuggingFace Hub is network-blocked, so we ship a lightweight
TF-IDF + TruncatedSVD encoder that produces 384-dim vectors — the same
dimension as all-MiniLM-L6-v2.  On your local machine, flip
USE_SENTENCE_TRANSFORMERS = True and the real model loads transparently.
"""

from __future__ import annotations

import re
import logging
from functools import lru_cache
from typing import List, Optional

import numpy as np
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# ── Toggle: set True locally once HuggingFace access is available ──────────
USE_SENTENCE_TRANSFORMERS = True
EMBEDDING_DIM = 384          # matches all-MiniLM-L6-v2

# ── Stopwords (inline — no NLTK download needed) ───────────────────────────
STOPWORDS = {
    "i", "me", "my", "we", "our", "you", "your", "he", "she", "it", "they",
    "a", "an", "the", "and", "or", "but", "if", "in", "on", "at", "to",
    "for", "of", "with", "by", "from", "is", "are", "was", "were", "be",
    "been", "being", "have", "has", "had", "do", "does", "did", "will",
    "would", "could", "should", "may", "might", "shall", "can", "need",
    "want", "get", "got", "like", "looking", "find", "show", "please",
    "some", "any", "this", "that", "these", "those", "there", "here",
    "about", "just", "also", "very", "so", "no", "not", "yes", "okay",
    "something", "anything", "everything", "nothing",
}

# ── Intent keyword pools ────────────────────────────────────────────────────
INTENT_PATTERNS: list[tuple[str, list[str]]] = [
    ("greeting",    [r"\bhello\b", r"\bhi\b", r"\bhey\b", r"\bgood\s+(morning|afternoon|evening)\b"]),
    ("goodbye",     [r"\bbye\b", r"\bgoodbye\b", r"\bsee\s+you\b", r"\bthanks?\b.*bye\b"]),
    ("add_to_cart", [r"\badd\s+to\s+cart\b", r"\bput\s+in\s+(my\s+)?cart\b", r"\bbuy\s+this\b", r"\bpurchase\b"]),
    ("checkout",    [r"\bcheckout\b", r"\bcheck\s+out\b", r"\bplace\s+(my\s+)?order\b", r"\bpay\b"]),
    ("filter",      [r"\bfilter\b", r"\bsort\b", r"\bonly\b.*(under|above|below|price|rating|brand)",
                     r"\bshow\s+(me\s+)?(only|just)\b"]),
    ("search",      [r"\bdo\s+you\s+(have|carry|sell|stock)\b", r"\bis\s+there\s+a\b",
                     r"\bcan\s+i\s+(get|find|buy|order)\b", r"\bdo\s+you\s+have\b"]),
    ("question",    [r"\bwhat\b", r"\bhow\b", r"\bwhy\b", r"\bwhen\b", r"\bwhere\b", r"\bwhich\b",
                     r"\bdoes\s+it\b"]),
    ("search",      [r"\blooking\s+for\b", r"\bneed\b", r"\bwant\b", r"\bfind\b", r"\bsearch\b",
                     r"\bshow\s+me\b", r"\brecommend\b", r"\bsuggest\b", r"\bbest\b",
                     # descriptive noun-phrase queries (e.g. "sporty gym shoes", "formal jacket for …")
                     r"\b(shoes|shoe|sneakers|boots|sandals|shirt|jacket|pants|dress|bag|watch|headphone|laptop|phone|camera|gun|firearm|weapon|knife|explosive)\b"]),
]
# ── Restricted product keywords ──
RESTRICTED_KEYWORDS = {"gun", "firearm", "weapon", "knife", "explosive"}
# Extract product type keywords (e.g., shoes, boots, etc.)
def extract_product_type_keywords(text: str) -> list[str]:
    types = ["shoes", "shoe", "sneakers", "boots", "sandals", "shirt", "jacket", "pants", "dress", "bag", "watch", "headphone", "laptop", "phone", "camera"]
    found = []
    for t in types:
        if re.search(rf"\b{re.escape(t)}\b", text.lower()):
            found.append(t)
    return found

# ── Budget patterns ─────────────────────────────────────────────────────────
BUDGET_PATTERNS = [
    r"\$\s*(\d+(?:\.\d+)?)(?!\s*(?:off|discount|sale))",  # bare $1000
    r"under\s+\$?\s*(\d+(?:\.\d+)?)",
    r"below\s+\$?\s*(\d+(?:\.\d+)?)",
    r"less\s+than\s+\$?\s*(\d+(?:\.\d+)?)",
    r"max(?:imum)?\s+\$?\s*(\d+(?:\.\d+)?)",
    r"up\s+to\s+\$?\s*(\d+(?:\.\d+)?)",
    r"around\s+\$?\s*(\d+(?:\.\d+)?)",
    r"about\s+\$?\s*(\d+(?:\.\d+)?)",
    r"budget\s+(?:is\s+|of\s+)?\$?\s*(\d+(?:\.\d+)?)",
    r"\$\s*(\d+(?:\.\d+)?)\s*(?:or\s+less|max)",
    r"(\d+(?:\.\d+)?)\s+dollars?\s+(?:or\s+less|max|budget)",
    r"spend\s+(?:at\s+most\s+|no\s+more\s+than\s+)?\$?\s*(\d+(?:\.\d+)?)",
]

# ── Urgency patterns ────────────────────────────────────────────────────────
URGENCY_HIGH = [
    r"\burgent(?:ly)?\b", r"\bneed\s+it\s+(?:today|now|asap|right\s+away)\b",
    r"\bright\s+now\b", r"\bimmediately\b", r"\bsoon\b", r"\bquick(?:ly)?\b",
    r"\bfast\b", r"\btoday\b", r"\bthis\s+week\b",
]
URGENCY_LOW = [
    r"\bno\s+rush\b", r"\bwhenever\b", r"\btake\s+your\s+time\b",
    r"\bno\s+hurry\b", r"\bcasually\b", r"\beventually\b",
]

# ── Style preference terms ──────────────────────────────────────────────────
STYLE_TERMS = {
    "casual":   ["casual", "everyday", "relaxed", "laid-back", "chill", "comfortable"],
    "formal":   ["formal", "business", "professional", "office", "corporate", "elegant"],
    "sporty":   ["sporty", "athletic", "sport", "gym", "workout", "active", "performance"],
    "modern":   ["modern", "contemporary", "minimalist", "sleek", "trendy", "stylish"],
    "vintage":  ["vintage", "retro", "classic", "old-school", "traditional"],
    "outdoor":  ["outdoor", "hiking", "camping", "adventure", "rugged", "waterproof"],
    "luxury":   ["luxury", "premium", "high-end", "designer", "exclusive"],
}


# ═══════════════════════════════════════════════════════════════════════════
# Pydantic output schema
# ═══════════════════════════════════════════════════════════════════════════

class UserIntent(BaseModel):
    intent: str = Field(
        description="One of: search, filter, add_to_cart, checkout, question, greeting, goodbye, unknown"
    )
    budget: Optional[float] = Field(None, description="Extracted price ceiling in USD")
    style_preference: Optional[str] = Field(None, description="Detected style preference")
    urgency: Optional[str] = Field(None, description="low | medium | high")
    keywords: List[str] = Field(default_factory=list, description="Key product-related tokens (including product type if present)")
    embedding: List[float] = Field(
        default_factory=list,
        description=f"Sentence embedding vector ({EMBEDDING_DIM}-dim)"
    )


# ═══════════════════════════════════════════════════════════════════════════
# Embedding backends
# ═══════════════════════════════════════════════════════════════════════════

class _SentenceTransformerBackend:
    """Real BERT-based encoder — requires network access to HuggingFace."""

    def __init__(self):
        from sentence_transformers import SentenceTransformer
        logger.info("Loading sentence-transformers/all-MiniLM-L6-v2 ...")
        self._model = SentenceTransformer("all-MiniLM-L6-v2")
        logger.info("Model loaded  dim=%d", self._model.get_sentence_embedding_dimension())

    def encode(self, text: str) -> List[float]:
        vec = self._model.encode(text, normalize_embeddings=True)
        return vec.tolist()


class _LocalEmbeddingBackend:
    """
    Lightweight TF-IDF + TruncatedSVD encoder.
    Produces 384-dim L2-normalised vectors — same shape as all-MiniLM-L6-v2.
    Seeded on a ~120 token vocabulary so embeddings are deterministic.
    Swap for the real model by setting USE_SENTENCE_TRANSFORMERS = True.
    """

    _VOCAB_SEED = [
        # electronics
        "phone","laptop","tablet","headphone","earphone","speaker","camera","monitor",
        "keyboard","mouse","charger","cable","battery","smart","wireless","bluetooth",
        "noise","cancelling","4k","gaming","rgb","mechanical","trackpad","display",
        # clothing
        "shirt","pants","jeans","dress","jacket","coat","hoodie","sweater","boots",
        "shoes","sneakers","sandals","hat","beanie","socks","underwear","suit","skirt",
        # home
        "vacuum","blender","coffee","mattress","pillow","shelf","lamp","furniture",
        "appliance","cookware","skillet","air","fryer","instant","pot","robot",
        # sports
        "yoga","mat","dumbbell","weight","kettlebell","bike","treadmill","resistance",
        "band","protein","basketball","tennis","golf","hiking","camping",
        # beauty
        "moisturizer","serum","sunscreen","mascara","foundation","lipstick","shampoo",
        "conditioner","perfume","deodorant","toner","exfoliant","cleanser",
        # intent / modifiers
        "buy","find","search","need","want","recommend","suggest","best","cheap",
        "affordable","expensive","budget","price","under","below","above","around",
        "brand","quality","rating","review","sale","discount","deal","gift","fast",
        "urgent","today","soon","casual","formal","sporty","modern","outdoor","luxury",
    ]

    def __init__(self):
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.decomposition import TruncatedSVD
        from sklearn.pipeline import Pipeline

        vocab = list(dict.fromkeys(self._VOCAB_SEED))
        # SVD n_components must be < n_features (vocab size).
        # We use min(vocab_size - 1, EMBEDDING_DIM) then zero-pad to EMBEDDING_DIM.
        n_components = min(len(vocab) - 1, EMBEDDING_DIM)
        self._n_components = n_components

        self._pipeline = Pipeline([
            ("tfidf", TfidfVectorizer(vocabulary=vocab, sublinear_tf=True)),
            ("svd",   TruncatedSVD(n_components=n_components, random_state=42)),
        ])

        # Fit on seed corpus so SVD has a stable basis
        seed_corpus = [" ".join(vocab[i:i+10]) for i in range(0, len(vocab), 5)]
        self._pipeline.fit(seed_corpus)
        logger.info(
            "Local embedding backend ready  svd_dim=%d  output_dim=%d",
            n_components, EMBEDDING_DIM
        )

    def encode(self, text: str) -> List[float]:
        vec = self._pipeline.transform([text.lower()])[0]   # shape: (n_components,)
        # Zero-pad to EMBEDDING_DIM so shape matches all-MiniLM-L6-v2
        if len(vec) < EMBEDDING_DIM:
            vec = np.concatenate([vec, np.zeros(EMBEDDING_DIM - len(vec))])
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        return vec.tolist()


# ═══════════════════════════════════════════════════════════════════════════
# Singleton loader
# ═══════════════════════════════════════════════════════════════════════════

@lru_cache(maxsize=1)
def _get_embedding_backend():
    if USE_SENTENCE_TRANSFORMERS:
        return _SentenceTransformerBackend()
    return _LocalEmbeddingBackend()


# ═══════════════════════════════════════════════════════════════════════════

# Core extraction helpers
# ═══════════════════════════════════════════════════════════════════════════

def _detect_intent(text: str) -> str:
    lower = text.lower()
    for intent, patterns in INTENT_PATTERNS:
        for pat in patterns:
            if re.search(pat, lower):
                return intent
    # Short replies (yes/no/what/ok) — keep as unknown so RL can handle gracefully
    return "unknown"

# Patch: extract product type keywords and flag restricted
def analyze(text: str) -> UserIntent:
    # Existing NLU logic...
    intent = _detect_intent(text)
    budget = _extract_budget(text)
    style = None
    for k, v in STYLE_TERMS.items():
        if any(word in text.lower() for word in v):
            style = k
            break
    urgency = _extract_urgency(text)
    keywords = extract_product_type_keywords(text)
    # Add all other non-stopword tokens as keywords
    tokens = [w for w in re.findall(r"\w+", text.lower()) if w not in STOPWORDS]
    for t in tokens:
        if t not in keywords:
            keywords.append(t)
    embedding = _get_embedding_backend().encode(text)
    return UserIntent(
        intent=intent,
        budget=budget,
        style_preference=style,
        urgency=urgency,
        keywords=keywords,
        embedding=embedding,
    )


def _extract_budget(text: str) -> Optional[float]:
    lower = text.lower()
    for pat in BUDGET_PATTERNS:
        m = re.search(pat, lower)
        if m:
            try:
                return float(m.group(1))
            except (ValueError, IndexError):
                continue
    return None


def _extract_urgency(text: str) -> Optional[str]:
    lower = text.lower()
    for pat in URGENCY_HIGH:
        if re.search(pat, lower):
            return "high"
    for pat in URGENCY_LOW:
        if re.search(pat, lower):
            return "low"
    if re.search(r"\bthis\s+(week|month)\b|\bsoon(?:ish)?\b", lower):
        return "medium"
    return None


def _extract_style(text: str) -> Optional[str]:
    lower = text.lower()
    for style, terms in STYLE_TERMS.items():
        for term in terms:
            if term in lower:
                return style
    return None


def _extract_keywords(text: str) -> List[str]:
    """
    Remove stopwords + punctuation, deduplicate, keep meaningful tokens.
    Lightweight proxy for noun/adjective extraction without POS tagging.
    """
    tokens = re.findall(r"[a-zA-Z]+", text.lower())
    seen: set[str] = set()
    keywords: List[str] = []
    for tok in tokens:
        if tok not in STOPWORDS and len(tok) > 2 and tok not in seen:
            seen.add(tok)
            keywords.append(tok)
    return keywords


# ═══════════════════════════════════════════════════════════════════════════
# Public NLU Service class
# ═══════════════════════════════════════════════════════════════════════════

class NLUService:
    """
    Singleton NLU service.  Call NLUService.get() to obtain the shared instance.
    """

    _instance: Optional["NLUService"] = None

    def __init__(self):
        self._backend = _get_embedding_backend()

    @classmethod
    def get(cls) -> "NLUService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def analyze(self, message: str) -> UserIntent:
        """
        Parse a raw user message and return a fully-populated UserIntent.
        """
        if not message or not message.strip():
            return UserIntent(
                intent="unknown",
                embedding=[0.0] * EMBEDDING_DIM,
            )

        return UserIntent(
            intent=_detect_intent(message),
            budget=_extract_budget(message),
            style_preference=_extract_style(message),
            urgency=_extract_urgency(message),
            keywords=_extract_keywords(message),
            embedding=self._backend.encode(message),
        )

    def embed(self, text: str) -> List[float]:
        """Return the raw embedding vector for a text string (used by RL state builder)."""
        return self._backend.encode(text)