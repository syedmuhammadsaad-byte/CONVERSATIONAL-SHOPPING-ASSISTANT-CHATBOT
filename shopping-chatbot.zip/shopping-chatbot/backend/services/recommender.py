"""
Recommender Service — Phase 4
==============================
Filters and ranks products from products.json based on NLU-extracted filters.

Ranking:
  1. Keyword relevance score  (name + tags + description match)
  2. Rating DESC              (tiebreaker)
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

# ── Path ───────────────────────────────────────────────────────────────────
_HERE         = os.path.dirname(__file__)
PRODUCTS_PATH = os.path.join(_HERE, "..", "data", "products.json")


# ═══════════════════════════════════════════════════════════════════════════
# Product schema
# ═══════════════════════════════════════════════════════════════════════════

class Product(BaseModel):
    id: int
    name: str
    category: str
    price: float
    brand: str
    rating: float
    tags: List[str]
    description: str
    stock: int


# ═══════════════════════════════════════════════════════════════════════════
# Recommender
# ═══════════════════════════════════════════════════════════════════════════

class Recommender:
    """
    Singleton product recommender.
    Use Recommender.get() to obtain the shared instance.
    """

    _instance: Optional["Recommender"] = None

    def __init__(self):
        with open(PRODUCTS_PATH, "r") as f:
            raw = json.load(f)
        self._products: List[Product] = [Product(**p) for p in raw]

    @classmethod
    def get(cls) -> "Recommender":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # ── Keyword relevance ──────────────────────────────────────────────────

    # Keyword synonyms — map user words to product tags
    _SYNONYMS = {
        "shoes":      ["shoes", "sneakers", "boots", "footwear", "running"],
        "shoe":       ["shoes", "sneakers", "boots", "footwear"],
        "sneakers":   ["sneakers", "shoes"],
        "boots":      ["boots", "shoes"],
        "shirt":      ["shirt", "tee", "top"],
        "pants":      ["pants", "jeans", "trousers"],
        "jacket":     ["jacket", "coat", "outerwear"],
        "headphones": ["headphones", "earphones", "audio", "wireless"],
        "laptop":     ["laptop", "computer"],
        "phone":      ["phone", "smartphone", "mobile"],
        "watch":      ["watch", "smartwatch"],
        "bag":        ["bag", "backpack", "handbag"],
    }

    def _relevance(self, product: Product, keywords: List[str]) -> int:
        """
        Count keyword matches against name, tags, description, category, brand.
        Expands keywords through synonym map for better recall.
        """
        if not keywords:
            return 0

        # Expand keywords with synonyms
        expanded = set()
        for kw in keywords:
            expanded.add(kw.lower())
            for syn in self._SYNONYMS.get(kw.lower(), []):
                expanded.add(syn)

        text = " ".join([
            product.name.lower(),
            " ".join(product.tags),
            product.description.lower(),
            product.category.lower(),
            product.brand.lower(),
        ])
        return sum(1 for kw in expanded if re.search(rf"\b{re.escape(kw)}\b", text))

    # ── Main public method ─────────────────────────────────────────────────

    def recommend(self, filters: Dict[str, Any], top_n: int = 5) -> List[Product]:
        """
        Filter and rank products.

        Supported filters
        -----------------
        category   : str   — exact match (case-insensitive)
        max_price  : float — upper price bound
        min_price  : float — lower price bound
        brand      : str   — exact match (case-insensitive)
        keywords   : list  — match against name / tags / description
        min_rating : float — minimum rating
        in_stock   : bool  — only show items with stock > 0

        Returns top_n products ranked by (relevance DESC, rating DESC).
        """
        results = list(self._products)

        category  = filters.get("category")
        max_price = filters.get("max_price")
        min_price = filters.get("min_price")
        brand     = filters.get("brand")
        keywords  = filters.get("keywords") or []
        min_rating = filters.get("min_rating")
        in_stock  = filters.get("in_stock", True)

        # ── Filters ────────────────────────────────────────────────────────
        if category:
            results = [p for p in results if p.category.lower() == category.lower()]

        if max_price is not None:
            results = [p for p in results if p.price <= max_price]

        if min_price is not None:
            results = [p for p in results if p.price >= min_price]

        if brand:
            results = [p for p in results if p.brand.lower() == brand.lower()]

        if min_rating is not None:
            results = [p for p in results if p.rating >= min_rating]

        if in_stock:
            results = [p for p in results if p.stock > 0]

        # ── Keyword filter: keep products with at least 1 match if keywords given ──
        if keywords:
            scored = [(p, self._relevance(p, keywords)) for p in results]
            # keep all if nothing matches keywords (fallback gracefully)
            matched = [(p, s) for p, s in scored if s > 0]
            if matched:
                scored = matched
        else:
            scored = [(p, 0) for p in results]

        # ── Rank: relevance DESC, rating DESC ──────────────────────────────
        scored.sort(key=lambda x: (x[1], x[0].rating), reverse=True)

        return [p for p, _ in scored[:top_n]]